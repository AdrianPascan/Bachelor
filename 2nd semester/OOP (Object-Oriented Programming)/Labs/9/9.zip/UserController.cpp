#pragma once

#include "UserController.h"
#include "BaseRepository.h"
#include <string.h>
#include <stdlib.h>
#include <algorithm>
#include <string>
#include "Validator.h"
#include "MyException.h"
#include <fstream>
#include <stdlib.h>

using namespace std;

//UserController::UserController()
//{
//}

UserController::UserController(BaseRepository * repository)
{
	this->repository = repository;
}


UserController::~UserController()
{
}

void UserController::setMylistPath(char * path)
{
	mylistPath.assign(path);
	writeToFile();
}

void UserController::setMatching(char * breed, char * vaccinations)
{
	vector<Dog> & dogs = this->repository->getAll();

	this->savedDogs.clear();

	if (breed == NULL) {
		this->matchingDogs = dogs;
	}
	else {
		int vaccinationsNumber = Validator::validatePositiveInteger(vaccinations);

		this->matchingDogs.resize(dogs.size());
		vector<Dog>::iterator last = copy_if(dogs.begin(), dogs.end(), this->matchingDogs.begin(),
			[breed, vaccinationsNumber](Dog & dog) {return (strcmp(dog.getBreed(), breed) == 0 && dog.getVaccinations() < vaccinationsNumber); });
		this->matchingDogs.resize(last - matchingDogs.begin());
	}
	this->currentDogPosition = this->matchingDogs.begin();

	writeToFile();
}

Dog & UserController::nextDog()
{
	if (this->matchingDogs.empty()) {
		throw MyException{ "None of the dogs match the criteria." };
	}
	if (this->currentDogPosition == this->matchingDogs.end()) {
		this->currentDogPosition = this->matchingDogs.begin();
	}
	return *(this->currentDogPosition++);
}

void UserController::saveDog(char * name)
{
	Dog dog{ name };

	vector<Dog>::iterator position = find_if(this->matchingDogs.begin(), this->matchingDogs.end(), [&dog](Dog & current) {return current == dog; });
	if (position == this->matchingDogs.end()) {
		throw MyException{ string{name} +" doesn't exist." };
	}

	vector<Dog>::iterator existing = find_if(this->savedDogs.begin(), this->savedDogs.end(), [&dog](Dog & current) {return current == dog; });
	if (existing != this->savedDogs.end()) {
		throw MyException{ string{name} +" already saved." };
	}

	this->savedDogs.push_back(*position);

	writeToFile();
}

std::vector<Dog> & UserController::getMatching()
{
	return this->matchingDogs;
}

void UserController::getSaved()
{
	system((string{ "cmd /C \"" } + mylistPath + "\"").c_str());
}

void UserController::writeToFile()
{
	string extension = mylistPath.substr(mylistPath.length() - 3);
	if (extension == "csv" || extension == "txt") {
		writeToCSV();
	}
	else {
		writeToHTML();
	}
}

void UserController::writeToCSV()
{
	ofstream descriptor(mylistPath);

	for (Dog & dog : savedDogs) {
		descriptor << dog;
	}

	descriptor.close();
}

void UserController::writeToHTML()
{
	ofstream stream(mylistPath);

	//HEADER
	stream << "<html>" << endl;
	stream << "<html>" << endl;
	stream << "<head>" << endl;
	//stream << "<title>Dogs</title>" << endl;
	stream << "</head>" << endl;
	stream << "<body>" << endl;
	stream << "<table>" << endl;
	//stream << "<table border=\"1\">" << endl;
	/*stream << "<tr>" << endl;
	stream << "<td>Name</td>" << endl;
	stream << "<td>Breed</td>" << endl;
	stream << "<td>Birth date</td>" << endl;
	stream << "<td>Number of vaccinations</td>" << endl;
	stream << "<td>Photohraph</td>" << endl;
	stream << "</tr>" << endl;*/

	//DOGS
	for (Dog & dog : savedDogs) {
		stream << "<tr>" << endl;
		stream << "<td>" << dog.getName() << "</td>" << endl;
		stream << "<td>" << dog.getBreed() << "</td>" << endl;
		stream << "<td>" << dog.getBirthDate() << "</td>" << endl;
		stream << "<td>" << dog.getVaccinations() << "</td>" << endl;
		stream << "<td><a href="<<dog.getPhotograph()<<">" << "Link" << "</a></td>" << endl;
		stream << "</tr>" << endl;
	}

	//FOOTER
	stream << "</table>" << endl;
	stream << "</body>" << endl;
	stream << "</html>" << endl;

	stream.close();
}
