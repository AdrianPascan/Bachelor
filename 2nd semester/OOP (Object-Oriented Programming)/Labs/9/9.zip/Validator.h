#pragma once


class Validator
{
public:
	//Validator();
	//~Validator();

	static int validateInteger(char *string);
	static int validatePositiveInteger(char *string);
};

