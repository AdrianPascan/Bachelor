#include "Repository.h"

using namespace std;

Repository::Repository()
{
	data.push_back(Weather{ 6,9,10,13,"foggy" });
	data.push_back(Weather{ 9,12,13,7,"cloudy" });
	data.push_back(Weather{ 12,14,18,23,"sunny" });
	data.push_back(Weather{ 14,18,20,52,"sunny" });
	data.push_back(Weather{ 18,21,20,68,"rainy" });
}


Repository::~Repository()
{
}

std::vector<Weather>& Repository::getAll()
{
	return data;
}

//void Repository::readFromFile()
//{
//	ifstream file{ "D:\Faculty\Sem. II\OOP (Object Oriented Programming)\Midterms\13\data.txt"};
//
//	string input{};
//
//	do {
//		getline(file, input);
//
//		if (!input.empty()) {
//			string data{};
//			stringstream stream{input};
//
//			for (int i = 0; i < 5; i++) {
//				
//			}
//		}
//
//	} while (!input.empty());
//
//	file.close();
//}
