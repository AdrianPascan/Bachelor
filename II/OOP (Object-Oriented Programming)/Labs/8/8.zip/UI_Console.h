#pragma once

#include "AdministratorController.h"
#include "UserController.h"

class UI_Console
{
private:
	char mode;
	AdministratorController * administratorController;
	UserController * userController;

public:
	UI_Console();
	UI_Console(AdministratorController * administratorController, UserController * userController);
	~UI_Console();

	void run();

private:
	char * getCommand();
	char ** getParameters(char * command, int & parametersCount);
	void destroyParameters(char **parameters, int parametersCount);
	void setMode(char **parameters, int parametersCount);
	void setFilePath(char **parameters, int parametersCount);
	void administratorCommand(char ** parameters, int parametersCount);
	void userCommand(char ** parameters, int parametersCount);
	void printDog(Dog & dog);
	void printDogList(std::vector<Dog>& dogs);
};

